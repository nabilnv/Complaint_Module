package com.example.sep_module_razzaq

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
